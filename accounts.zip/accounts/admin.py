from django.contrib import admin

from .views import USER

admin.site.register(USER)
